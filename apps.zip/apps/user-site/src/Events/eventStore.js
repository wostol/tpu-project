import { create } from 'zustand';
import { apiRequest } from '../auth/apiClient';

const normalizeEvent = (raw) => {
  if (!raw) return null;
  
  const start = new Date(raw.startDate);
  const end = new Date(raw.endDate);
  const durationMs = end - start;
  const hours = Math.floor(durationMs / (1000 * 60 * 60));
  const minutes = Math.round((durationMs % (1000 * 60 * 60)) / (1000 * 60));
  const duration = minutes > 0 ? `${hours} ч. ${minutes} мин.` : `${hours} ч.`;
  
  const reg = raw.userRegistration || {};

  return {
    // 🔥 КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: Fallback на raw.id, если uuid отсутствует
    id: raw.uuid || raw.id, 
    title: raw.title,
    description: raw.description || '',
    fullDescription: raw.fullDescription || raw.description || '',
    
    myRole: raw.myRole || raw.registrationType || reg.role || 'participant',
    registeredAt: raw.registeredAt || reg.registeredAt || raw.createdAt || null,
    teamName: raw.teamName || reg.teamName || null,

    startDate: raw.startDate,
    endDate: raw.endDate,
    duration,
    location: raw.location || 'Адрес не указан',
    organizerId: raw.organizerId,
    participantPoints: raw.participantPoints || 0,
    fanPoints: raw.fanPoints || 0,
    maxParticipants: raw.maxParticipants || 0,
    currentParticipants: raw.currentParticipants || 0,
    currentFans: raw.currentFans || 0,

    isRegistered: Boolean(raw.isRegistered || reg.status),
    userRegistration: reg,

    status: raw.status || 'registration',
    eventType: raw.eventType || 'event',
    registrationDeadline: raw.registrationDeadline || null,

    level: raw.level || 'Не указан',
    price: raw.price ?? 0,
    requirements: raw.requirements || 'Не указаны',
    rules: raw.rules || 'Не указаны',
    equipment: raw.equipment || 'Не требуется',
    contactEmail: raw.contactEmail || null,
    contactPhone: raw.contactPhone || null,
    organizer: raw.organizerId ? `ID: ${raw.organizerId}` : 'Не указан',
    rewardsPoints: raw.participantPoints || 0,
  };
};

const useEventStore = create((set, get) => ({
  events: [],
  loading: false,
  error: null,
  selectedEvent: null,

  fetchEvents: async () => {
    set({ loading: true, error: null });
    try {
      const data = await apiRequest('/events', { method: 'GET' });
      const normalized = Array.isArray(data) ? data.map(normalizeEvent).filter(Boolean) : [];
      set({ events: normalized, loading: false });
      return normalized;
    } catch (error) {
      set({ error: error.message, loading: false });
      return [];
    }
  },

  fetchMyEvents: async () => {
    set({ loading: true, error: null });
    try {
      const data = await apiRequest('/events', { method: 'GET' });
      const registeredEvents = Array.isArray(data) ? data.filter(e => e.isRegistered) : [];
      const normalized = registeredEvents.map(normalizeEvent).filter(Boolean);

      const fullEvents = await Promise.all(
        normalized.map(async (event) => {
          try {
            const fullEvent = await get().fetchEventById(event.id, true);
            return fullEvent || event;
          } catch (err) {
            console.warn(`Не удалось загрузить детали для события ${event.id}:`, err);
            return event;
          }
        })
      );

      set({ events: fullEvents, loading: false });
      return fullEvents;
    } catch (error) {
      set({ error: error.message, loading: false });
      return [];
    }
  },

  fetchEventById: async (id, skipLoadingState = false) => {
     if (!id) {
    console.error('[eventStore] fetchEventById called without id');
    return null;
  }
  
  if (!skipLoadingState) {
    set({ loading: true, error: null });
  }
  
  try {
    const rawData = await apiRequest(`/events/${id}`, {
      method: 'GET',
    });
    
    const normalized = normalizeEvent(rawData);

    // 🔥 ЗАЩИТА: если ID нет, не продолжаем
    if (!normalized || !normalized.id) {
      console.error('[eventStore] Event has no ID:', rawData);
      if (!skipLoadingState) {
        set({ loading: false, error: 'Invalid event data', selectedEvent: null });
      }
      return null;
    }

    set((state) => {
      const existingIndex = state.events.findIndex(e => e.id === normalized.id);

        const mergedEvent = existingIndex !== -1
          ? { ...state.events[existingIndex], ...normalized }
          : normalized;

        const newEvents = existingIndex !== -1
          ? state.events.map((e, i) => i === existingIndex ? mergedEvent : e)
          : [...state.events, mergedEvent];

        return {
          selectedEvent: mergedEvent,
          events: newEvents,
          loading: skipLoadingState ? state.loading : false,
        };
      });

      return normalized;
    } catch (error) {
      if (!skipLoadingState) {
        set({ error: error.message, loading: false, selectedEvent: null });
      }
      return null;
    }
  },

  fetchEventDetailsOnly: async (id) => get().fetchEventById(id),
  
getEventFromList: (id) => {
  const { events } = get();
  return events.find((e) => e.id === id) || null;
},

updateEvent: (id, updates) => {
  set((state) => ({
    events: state.events.map((e) => (e.id === id ? { ...e, ...updates } : e)),
    selectedEvent: state.selectedEvent?.id === id
      ? { ...state.selectedEvent, ...updates }
      : state.selectedEvent,
  }));
},

  registerForEvent: async (eventId, registrationType) => {
    set({ loading: true, error: null });
    try {
      const result = await apiRequest(`/events/${eventId}/register`, {
        method: 'POST',
        body: JSON.stringify({ eventId, registrationType }),
      });
      await get().fetchEventById(eventId);
      set({ loading: false });
      return result;
    } catch (error) {
      console.error(`❌ Ошибка регистрации на событие #${eventId}:`, error);
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  unsubscribeFromEvent: async (eventId) => {
    set({ loading: true, error: null });
    try {
      await apiRequest(`/events/${eventId}/unregister`, { method: 'DELETE' });
      set((state) => ({
        events: state.events.filter((e) => e.id !== eventId),
        selectedEvent: state.selectedEvent?.id === eventId ? null : state.selectedEvent,
        loading: false,
      }));
      return { success: true };
    } catch (error) {
      console.error(`❌ Ошибка отписки от события #${eventId}:`, error);
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  // 🔥 Полная очистка состояния при уходе со страницы
  clearSelectedEvent: () => set({ selectedEvent: null, error: null, loading: false }),
  clearError: () => set({ error: null }),
}));

export const useEvents = () => useEventStore((state) => state.events);
export const useEventLoading = () => useEventStore((state) => state.loading);
export const useEventError = () => useEventStore((state) => state.error);
export const useSelectedEvent = () => useEventStore((state) => state.selectedEvent);
export default useEventStore;